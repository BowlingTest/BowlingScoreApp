package com.test.context;

import cern.colt.map.OpenIntObjectHashMap;
import com.test.context.frame.FinalFrame;
import com.test.context.frame.OpenFrame;
import com.test.exceptions.InValidRollException;
import java.util.LinkedList;

/**
 * Created by svmen on 9/8/2021.
 */
public class PlayerContext extends Context {

  public static final int FRAME_MAX_SIZE = 30;
  public static final String CURRENT_GAME_TOTAL = "Current Game Total ";
  private static final int MAX_SIZE =10;
  public static final int FINAL_FRAME_COUNT =9;

  //Keep a rolling list of bonus eligible frames
  private final LinkedList<OpenFrame> bonusFrames;

  //Open source map, keep the object cost low.with primitive keys.
  private final OpenIntObjectHashMap gamesFrameIntMap;
  private int gameFrameCounter =0;
  private int currentTotal =0;

  public PlayerContext(){
    bonusFrames = new LinkedList<>();
    gamesFrameIntMap = new OpenIntObjectHashMap();
  }

  public int updateOpenFrame(final int roll) throws InValidRollException {
    OpenFrame bonusEligible = null;

    if(roll<0){
      throw new InValidRollException("Roll value cannot be negative ");
    }

    if(gamesFrameIntMap.size() ==0){
      System.out.println("Starting a new Game ");
    }

    if(gameFrameCounter >= FINAL_FRAME_COUNT){
      //update calculation for final frame
      calculateFinalFrame(roll);
    }else{
      OpenFrame openFrame = (OpenFrame)gamesFrameIntMap.get(gameFrameCounter);
      if(openFrame == null){
        openFrame = new OpenFrame(gameFrameCounter);
      }
      if(openFrame.getCurrentFrameCount() == 0){
        openFrame.updateFirstTry(roll);
      }else{
        openFrame.updateSecondTry(roll);
      }

      gamesFrameIntMap.put(gameFrameCounter,openFrame);

      if(openFrame.isFrameClosed()){
        openFrame.markSpare();
        openFrame.markStrike();

        if(openFrame.isStrike()){
          bonusFrames.add(openFrame);
        }

        if(bonusFrames.size() > 1){
          bonusEligible = updateBonusEligibleFrames(null,openFrame);
          if(bonusEligible.isBonusApplied()){
            bonusFrames.remove(bonusEligible);
          }
        }

        OpenFrame bonusEligibleFrame = (OpenFrame) gamesFrameIntMap.get(gameFrameCounter-1);
        if(bonusEligibleFrame!=null && bonusEligibleFrame.isStrike()){
          if(!bonusEligibleFrame.equals(bonusEligible)){
            int frameTotal = openFrame.getFrameTotal();
            bonusEligibleFrame.updateFrameTotal(frameTotal);
            currentTotal = currentTotal+frameTotal;
          }
        }

        if(bonusEligibleFrame !=null && bonusEligibleFrame.isSpareBonusEligible){
          int frameTotal = openFrame.firstTry;
          bonusEligibleFrame.updateFrameTotal(openFrame.firstTry);
          currentTotal = currentTotal+frameTotal;
        }
      }

      if(openFrame.isFrameClosed()){
        currentTotal = currentTotal +openFrame.getFrameTotal();
        gameFrameCounter++;
      }
    }
    return currentTotal;
  }

  private void calculateFinalFrame(final int roll){
    FinalFrame finalFrame = (FinalFrame) gamesFrameIntMap.get(gameFrameCounter);

    if(finalFrame==null){
      finalFrame = new FinalFrame(gameFrameCounter);
    }
    if(finalFrame.numberOftries ==0 ){
      finalFrame.updateFirstTry(roll);
    }else if(finalFrame.numberOftries==1){
      finalFrame.updateSecondTry(roll);
    }else{
      finalFrame.updateThirdTry(roll);
    }

    if(finalFrame.isStrike()){
      if(bonusFrames.size()>0){
        OpenFrame bonusEligibale = updateBonusEligibleFrames(finalFrame,null);
        if(bonusEligibale.getFrameTotal() != FRAME_MAX_SIZE){
          if(bonusEligibale.isBonusApplied()){
            bonusFrames.remove(bonusEligibale);
          }
        }else{
          bonusFrames.remove(bonusEligibale);
        }
      }
    }
    gamesFrameIntMap.put(gameFrameCounter,finalFrame);

    if(finalFrame.isFrameClosed()){
      if(finalFrame.isStrike() || finalFrame.isSpare()){
        currentTotal = currentTotal + finalFrame.frameTotal;
      }else{
        currentTotal = currentTotal+finalFrame.firstTry+finalFrame.secondTry;
      }
      gameFrameCounter++;
    }
  }

  private OpenFrame updateBonusEligibleFrames(final FinalFrame finalFrame, final OpenFrame openFrame){
    OpenFrame bonusEligiable = bonusFrames.getFirst();
    int frameTotal = 0;
    if(finalFrame!=null){
      frameTotal = finalFrame.frameTotal;
      currentTotal = currentTotal+frameTotal;
      bonusEligiable.updateFrameTotal(frameTotal);
    }else{
      frameTotal = openFrame.frameTotal;
      currentTotal = currentTotal + frameTotal;
      bonusEligiable.updateFrameTotal(frameTotal);
    }
    return bonusEligiable;
  }

  //Test Method , in case we want to go fancy with display
  private int getDisplayScore(final OpenIntObjectHashMap gamesFrameIntMap,boolean isFinal ){
    int gameSize = gamesFrameIntMap.size();
    int total = 0;

    for(int i=0 ; i < gameSize;i++){
      if(i!=FINAL_FRAME_COUNT){
        OpenFrame openFrame =(OpenFrame)gamesFrameIntMap.get(i);
        total = total+openFrame.frameTotal;
      }
    }
    if(isFinal){
      FinalFrame finalFrame =(FinalFrame)gamesFrameIntMap.get(FINAL_FRAME_COUNT);
      total =total+finalFrame.frameTotal;
    }
    System.out.println("FRame Total is "+total);
    return total;
  }

  public int getGameSize(){
    return  gameFrameCounter;
  }

}
