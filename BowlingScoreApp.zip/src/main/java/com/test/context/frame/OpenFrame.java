package com.test.context.frame;

import java.util.Objects;

/**
 * Created by svmen on 9/8/2021.
 *
 * @Desc : Open frame wil hold the current frame being played. Will hold details on the score/bonus
 * etc..
 */
public class OpenFrame extends Frame {

  private int bonusComplete = 0;
  private int numberOfTries = 0;
  private final int frameNumber;

  public boolean isSpareBonusEligible;
  public boolean isStrikeBonusEligible;


  public OpenFrame(final int frameNumber) {
    this.frameNumber = frameNumber;
  }

  /**
   * Update the frame for first roll
   */
  public void updateFirstTry(final int roll) {
    this.firstTry = roll;
    if (markStrike()) {
      numberOfTries = MAx_FRAME_COUNT;
    } else {
      numberOfTries++;
    }
    frameTotal = frameTotal + roll;
  }

  public void updateSecondTry(final int roll) {
    this.secondTry = roll;
    frameTotal = frameTotal + roll;
    numberOfTries++;
  }

  public void updateFrameTotal(final int bonus) {
    frameTotal = frameTotal + bonus;
    bonusComplete++;
  }

  public boolean markSpare() {
    if (firstTry + secondTry == MAX_POSSIBLE && !isStrikeBonusEligible) {
      isSpareBonusEligible = true;
    }
    return isSpareBonusEligible;
  }

  public boolean isStrike() {
    return isStrikeBonusEligible;
  }

  public boolean isSpare() {
    return isSpareBonusEligible;
  }

  public boolean markStrike() {
    if (firstTry == MAX_POSSIBLE) {
      isStrikeBonusEligible = true;
    }
    return isStrikeBonusEligible;
  }

  public boolean isFrameClosed() {
    return numberOfTries == MAx_FRAME_COUNT;
  }

  public int getFrameNumber() {
    return frameNumber;
  }

  public int getCurrentFrameCount() {
    return numberOfTries;
  }

  public int getFrameTotal() {
    return frameTotal;
  }

  public boolean isBonusApplied() {
    return bonusComplete == MAX_BONUS_COUNT;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof OpenFrame)) {
      return false;
    }
    OpenFrame openFrame = (OpenFrame) o;
    return bonusComplete == openFrame.bonusComplete &&
        numberOfTries == openFrame.numberOfTries &&
        getFrameNumber() == openFrame.getFrameNumber() &&
        isSpareBonusEligible == openFrame.isSpareBonusEligible &&
        isStrikeBonusEligible == openFrame.isStrikeBonusEligible &&
        firstTry == openFrame.firstTry &&
        secondTry == openFrame.secondTry &&
        getFrameTotal() == openFrame.getFrameTotal();
  }

  @Override
  public int hashCode() {
    return Objects.hash(bonusComplete, numberOfTries, getFrameNumber(), isSpareBonusEligible,
        isStrikeBonusEligible, firstTry, secondTry, getFrameTotal());
  }

  @Override
  public String toString() {
    return "OpenFrame{" +
        "bonusComplete=" + bonusComplete +
        ", numberOfTries=" + numberOfTries +
        ", frameNumber=" + frameNumber +
        ", isSpareBonusEligible=" + isSpareBonusEligible +
        ", isStrikeBonusEligible=" + isStrikeBonusEligible +
        ", firstTry=" + firstTry +
        ", secondTry=" + secondTry +
        ", frameTotal=" + frameTotal +
        '}';
  }
}
