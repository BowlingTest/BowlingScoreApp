package com.test.exceptions;

/**
 * Created by svmen on 9/8/2021.
 */
public class InValidRollException extends Exception {

  public InValidRollException(final String message) {
    super(message);
  }
}
